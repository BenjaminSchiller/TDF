#!/bin/bash

date
sleep 2
date